<?php
/**
 * Focus grid block uses news focus block code 
 */

$the_block = 'focus-grid';

include locate_template('blocks/news-focus.php');