<?php

class Bunyad_Sliders
{
	public function init()
	{
	}
}